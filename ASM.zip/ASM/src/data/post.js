export const posts = ([
  { id: 1, title: 'Bài viết 1', content: 'Nội dung bài viết 1' },
  { id: 2, title: 'Bài viết 2', content: 'Nội dung bài viết 2' },
  { id: 3, title: 'Bài viết 3', content: 'Nội dung bài viết 3' },
  { id: 4, title: 'Bài viết 4', content: 'Nội dung bài viết 4' }
])