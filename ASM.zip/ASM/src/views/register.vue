<template>
  <div class="col-md-4 mx-auto">
    <h3 class="text-center">Đăng ký</h3>

    <form>
      <input class="form-control mb-2" placeholder="Tên">
      <input class="form-control mb-2" placeholder="Email">
      <input type="password" class="form-control mb-2" placeholder="Password">
      <button class="btn btn-secondary w-100">Register</button>
    </form>
  </div>
</template>
