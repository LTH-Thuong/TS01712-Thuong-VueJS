<template>
  <div class="col-md-6 mx-auto">
    <h3>Thông tin cá nhân</h3>

    <ul class="list-group">
      <div class="card blog">
                    <img src="../images/avatar.png" class="card-img-top" alt="...">
                    <li class="list-group-item">Tên: Nguyễn Văn A</li>
      <li class="list-group-item">Email: a@gmail.com</li>
                </div>
      
    </ul>
  </div>
</template>
